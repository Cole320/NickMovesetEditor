// compile with: /reference:UnityEngine.dll /reference:TypeBindConflicts=UnityEngine.CoreModule.dll  
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using HarmonyLib;
using Nick;
using static Nick.MusicMetaData;
using UnityEngine.Networking;
using System.Linq;
using UnityEngine;
using CharacterLoader.Utils;
using CharacterLoader;
using System.Reflection;

namespace CharacterLoader.Patches
{
	[HarmonyPatch(typeof(SetUpGame), "SetBattleModeText")]

    public class CharacterSelectScreen_MenuOpen
    {

		static CharacterMetaData GetCharacterById(string id)
		{
			foreach (CharacterMetaData characterMetaData in GameObject.Find("test").GetComponent<Nick.GameStartScript>().gmd.characterMetas)
			{
				if (characterMetaData.id == id)
				{
					return characterMetaData;
				}
			}
			CharLoaderPlugin.LogInfo("Character not found: " + id);
			return null;
		}
        public static SetUpGame realgame;

        public static void Postfix(SetUpGame __instance)
        {
            if (GameObject.Find("charselect(Clone)") == null) {
                CharLoaderPlugin.LogInfo("can't find the character select we need");
                realgame = __instance;
            } else
            {
                CharLoaderPlugin.LogInfo("Huh. apparently the charselect clone does exist this early");
                realgame = GameObject.Find("charselect(Clone)").GetComponent<Nick.SetUpGame>();
            }
            Thefix();
        }

        public static void RecenterSlots()
        {
            Transform[] rows = new Transform[3];
            rows[0] = GameObject.Find("charselect(Clone)").transform.Find("Canvas/MainContainer/CharacterSlots/Row1");
            rows[1] = GameObject.Find("charselect(Clone)").transform.Find("Canvas/MainContainer/CharacterSlots/Row2");
            rows[2] = GameObject.Find("charselect(Clone)").transform.Find("Canvas/MainContainer/CharacterSlots/Row3");
            int basecount = rows[0].childCount;
            CharLoaderPlugin.LogDebug("default row count: " + basecount);
           foreach (Transform theeye in rows)
           {
               theeye.GetComponent<RectTransform>().anchoredPosition = new Vector3(basecount - theeye.childCount * 100, theeye.GetComponent<RectTransform>().anchoredPosition.y, 0);
           }
            GameObject.Find("charselect(Clone)").transform.Find("Canvas/MainContainer/CharacterSlots").GetComponent<RectTransform>().anchoredPosition = new Vector3((Screen.width / basecount) * (float) -1.5, GameObject.Find("charselect(Clone)").transform.Find("Canvas/MainContainer/CharacterSlots").GetComponent<RectTransform>().anchoredPosition.y, 0);


        }

        public static void Thefix()
		{
            CharLoaderPlugin.LogInfo("Postfix for CharacterSelectScreen_MenuOpen was called!");


            GameObject menuobj = GameObject.Find("charselect(Clone)");
            Dictionary<CharacterMetaData, CharacterSlotData> ___slotLookup = GameObject.Find("test/menu/charselect(Clone)").GetComponent<Nick.SetCharacterSlots>().GetPrivateField<Dictionary<CharacterMetaData, CharacterSlotData>>("slotLookup");
            //Postfix(GameObject.Find("test/menu/charselect(Clone)").GetComponent<SetCharacterSlots>(), ___slotLookup);
            if (menuobj != null)
			{
				if (menuobj.transform.Find("Canvas/MainContainer/OnlineMatchInfo").gameObject != null)
                {
					if (menuobj.transform.Find("Canvas/MainContainer/OnlineMatchInfo").gameObject.GetComponent<OnlineMatchInfo>() != null)
					{
						List<Nick.OnlineLobby.User> matchy = menuobj.transform.Find("Canvas/MainContainer/OnlineMatchInfo").gameObject.GetComponent<OnlineMatchInfo>().GetPrivateField<List<Nick.OnlineLobby.User>>("userList");
                        CharLoaderPlugin.LogInfo("userList count:" + matchy.Count);
						if (matchy != null)
                        {
							var typo = typeof(Nick.OnlineLobby).GetNestedType("RealUser", BindingFlags.NonPublic);
                            if (matchy.Count > 1)
                            {
                                for (var users = 0; users < matchy.Count; users++)

                                {
                                    if (matchy[users].Id != null)
                                    {
                                        CharLoaderPlugin.LogInfo("applying stuff to user " + matchy[users].Nick);
                                        //typeof(Nick.OnlineLobby).GetNestedType("RealUser", BindingFlags.NonPublic) var TheUser = new typo();

                                        if (matchy[users].Id.GetPrivateField<Photon.Realtime.Player>("realPlayer").CustomProperties != null)
                                        {
                                            CharLoaderPlugin.LogInfo("user has CustomProperties!");
                                            if (matchy[users].Id.GetPrivateField<Photon.Realtime.Player>("realPlayer").CustomProperties.ContainsKey("customChars"))
                                            {
                                                CharLoaderPlugin.LogInfo("user has Custom Characters!");
                                                object charlist = "";
                                                List<String> charlistParsed = new List<string>();
                                                matchy[users].Id.GetPrivateField<Photon.Realtime.Player>("realPlayer").CustomProperties.TryGetValue("customChars", out charlist);
                                                CharLoaderPlugin.LogDebug(charlist.ToString());
                                                charlistParsed = charlist.ToString().Split('|').ToList<string>();
                                                CharLoaderPlugin.LogInfo("raw custom characters list: " + charlist);

                                                for (var rem = 0; rem < Management.CustomCharacterManager.customCharList.Count; rem++)
                                                {
                                                    if (charlistParsed.Contains(Management.CustomCharacterManager.customCharList[rem]))
                                                    {
                                                        CharLoaderPlugin.LogInfo("Other player " + matchy[users].Nick + " has your custom character " + Management.CustomCharacterManager.customCharList[rem] + " , but will not be enabled for safety");
                                                    }
                                                    else
                                                    {
                                                        CharLoaderPlugin.LogError("other player " + matchy[users].Nick + " doesnt have custom character " + Management.CustomCharacterManager.customCharList[rem] + " ; removing from css");
                                                        menuobj.GetComponent<SetCharacterSlots>().GetSlotForChar(GetCharacterById(Management.CustomCharacterManager.customCharList[rem])).gameObject.SetActive(false);
                                                        RecenterSlots();
                                                    }

                                                }

                                            }
                                            else
                                            {
                                                CharLoaderPlugin.LogError("other player " + matchy[users].Nick + " has no custom characters");
                                                for (var rem = 0; rem < Management.CustomCharacterManager.customCharList.Count; rem++)
                                                {
                                                    menuobj.GetComponent<SetCharacterSlots>().GetSlotForChar(GetCharacterById(Management.CustomCharacterManager.customCharList[rem])).gameObject.SetActive(false);
                                                    RecenterSlots();
                                                }
                                            }

                                        }
                                        else
                                        {
                                            CharLoaderPlugin.LogError("other player " + matchy[users].Nick + " has no customproperties! like, at all!");
                                        }


                                    } else
                                    {
                                        CharLoaderPlugin.LogError("Reached a null spot in the playerlist!");
                                    }
                                }
                            } else
                            {
                                CharLoaderPlugin.LogInfo("You're offline/the only player!");
                                for (var phew = 0; phew < Management.CustomCharacterManager.customCharList.Count; phew++) {

                                    menuobj.GetComponent<SetCharacterSlots>().GetSlotForChar(GetCharacterById(Management.CustomCharacterManager.customCharList[phew])).gameObject.SetActive(true);
                                    RecenterSlots();
                                }

                            }

                        } else
                        {
							CharLoaderPlugin.LogError("apparently this SetCharacterSlots' OnlineMatchInfo component hates your guts!");
						}
						

					}
					else
					{
						CharLoaderPlugin.LogError("apparently this SetCharacterSlots has no OnlineMatchInfo component!");
					}

				} else
                {
					CharLoaderPlugin.LogError("apparently this SetCharacterSlots has no OnlineMatchInfo gameObject!");
				}

			} else
            {
				CharLoaderPlugin.LogError("apparently this SetCharacterSlots has no gameObject!");
                if (GameObject.Find("test/menu/charselect(Clone)") != null)
                {
                    CharacterLoader.Patches.CharacterSelectScreen_MenuOpen.Postfix(GameObject.Find("charselect(Clone)").GetComponent<Nick.SetUpGame>());
                }
            }
		}
	}
}