// compile with: /reference:UnityEngine.dll /reference:TypeBindConflicts=UnityEngine.CoreModule.dll  
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using HarmonyLib;
using Nick;
using static Nick.MusicMetaData;
using UnityEngine.Networking;
using System.Linq;
using UnityEngine;
using CharacterLoader.Utils;
using CharacterLoader;
using System.Reflection;

namespace CharacterLoader.Patches
{
	[HarmonyPatch(typeof(GameVOEventsTrigger), "OnTitleScreen")]
	class GameVOEventsTrigger_OnTitleScreen
	{
       public static void Postfix()
		{
			if (Management.CustomCharacterManager.customCharList == null && Directory.Exists(Path.Combine(BepInEx.Paths.BepInExRootPath, "CustomChars")))
            {
				Management.CustomCharacterManager.Init();
            }
			GameObject FindInActiveObjectByName(string name)
			{
				Transform[] objs = Resources.FindObjectsOfTypeAll<Transform>() as Transform[];
				for (int i = 0; i < objs.Length; i++)
				{
					if (objs[i].hideFlags == HideFlags.None)
					{
						if (objs[i].name == name)
						{
							return objs[i].gameObject;
						}
					}
				}
				return null;
			}
			GameObject slotloader = FindInActiveObjectByName("CharacterSlot");
			GameObject playerslota = FindInActiveObjectByName("Player1Slot");
			GameObject playerslotb = FindInActiveObjectByName("Player2Slot");
			GameObject playerslotc = FindInActiveObjectByName("Player3Slot");
			GameObject playerslotd = FindInActiveObjectByName("Player4Slot"); //i hope i wrote lots of spaghetti
			GameObject ingameslota = FindInActiveObjectByName("PlayerUI");
			GameObject ingameslotb = FindInActiveObjectByName("PlayerUI (1)");
			GameObject ingameslotc = FindInActiveObjectByName("PlayerUI (2)");
			GameObject ingameslotd = FindInActiveObjectByName("PlayerUI (3)");

			for (var sea = 0; sea < Management.CustomCharacterManager.newCharacters.Length; sea++)
            {

				if (slotloader != null && Management.CustomCharacterManager.newCharacters != null)
				{
					CharLoaderPlugin.LogInfo("Found the CharacterSlot object!");
					GameObject newcharicon = GameObject.Instantiate(slotloader.transform.Find("Mask/CharacterSlotRenderVisualizer/RenderVisualizer/Characters/SpongeBob").gameObject);
					newcharicon.GetComponent<RenderImage>().CharacterMetaData = Management.CustomCharacterManager.newCharacters[sea];
					newcharicon.name = Management.CustomCharacterManager.newCharacters[sea].id;
					newcharicon.transform.SetParent(slotloader.transform.Find("Mask/CharacterSlotRenderVisualizer/RenderVisualizer/Characters"));

					GameObject newcharrender = GameObject.Instantiate(playerslota.transform.Find("Character/PlayerSlotRenderVisualizer/RenderVisualizer/Characters/SpongeBob").gameObject);
					newcharrender.GetComponent<RenderImage>().CharacterMetaData = Management.CustomCharacterManager.newCharacters[sea];
					newcharrender.name = Management.CustomCharacterManager.newCharacters[sea].id;
					newcharrender.transform.SetParent(playerslota.transform.Find("Character/PlayerSlotRenderVisualizer/RenderVisualizer/Characters"));
					newcharrender.transform.localScale = new Vector3(1, 1, 1);

					GameObject newcharrendertoo = GameObject.Instantiate(newcharrender);
					newcharrendertoo.GetComponent<RenderImage>().CharacterMetaData = Management.CustomCharacterManager.newCharacters[sea];
					newcharrendertoo.name = Management.CustomCharacterManager.newCharacters[sea].id;
					
					newcharrendertoo.transform.SetParent(playerslotb.transform.Find("Character/PlayerSlotRenderVisualizer/RenderVisualizer/Characters"));
					newcharrendertoo.transform.localScale = new Vector3(1, 1, 1);

					GameObject newcharrendertoobe = GameObject.Instantiate(newcharrender);
					newcharrendertoobe.GetComponent<RenderImage>().CharacterMetaData = Management.CustomCharacterManager.newCharacters[sea];
					newcharrendertoobe.name = Management.CustomCharacterManager.newCharacters[sea].id;
					
					newcharrendertoobe.transform.SetParent(playerslotc.transform.Find("Character/PlayerSlotRenderVisualizer/RenderVisualizer/Characters"));
					newcharrendertoobe.transform.localScale = new Vector3(1, 1, 1);

					GameObject newcharrendertoona = GameObject.Instantiate(newcharrender);
					newcharrendertoona.GetComponent<RenderImage>().CharacterMetaData = Management.CustomCharacterManager.newCharacters[sea];
					newcharrendertoona.name = Management.CustomCharacterManager.newCharacters[sea].id;
					
					newcharrendertoona.transform.SetParent(playerslotd.transform.Find("Character/PlayerSlotRenderVisualizer/RenderVisualizer/Characters"));
					newcharrendertoona.transform.localScale = new Vector3(1, 1, 1);

					GameObject newuia = GameObject.Instantiate(ingameslota.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters/SpongeBob").gameObject);
					newuia.GetComponent<RenderImage>().CharacterMetaData = Management.CustomCharacterManager.newCharacters[sea];
					newuia.GetComponent<RenderImage>().InvokeMethod("SetTexture", Management.CustomCharacterManager.newCharacters[sea].resCSSMiniPortrait);
					newuia.name = Management.CustomCharacterManager.newCharacters[sea].id;
					newuia.transform.SetParent(ingameslota.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters"));
					newuia.transform.position = ingameslota.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters/SpongeBob").position;
					newuia.transform.localPosition = ingameslota.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters/SpongeBob").localPosition;
					newuia.transform.localScale = new Vector3(1, 1, 1);


					GameObject newuib = GameObject.Instantiate(ingameslotb.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters/SpongeBob").gameObject);
					newuib.GetComponent<RenderImage>().CharacterMetaData = Management.CustomCharacterManager.newCharacters[sea];
					newuib.name = Management.CustomCharacterManager.newCharacters[sea].id;
					newuib.transform.position = ingameslotb.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters/SpongeBob").position;
					newuib.transform.localPosition = ingameslotb.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters/SpongeBob").localPosition;
					newuib.transform.localScale = new Vector3(1, 1, 1);
					newuib.transform.SetParent(ingameslotb.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters"));
					

					GameObject newuic = GameObject.Instantiate(ingameslotc.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters/SpongeBob").gameObject);
					newuic.GetComponent<RenderImage>().CharacterMetaData = Management.CustomCharacterManager.newCharacters[sea];
					newuic.GetComponent<RenderImage>().InvokeMethod("SetTexture", Management.CustomCharacterManager.newCharacters[sea].resCSSMiniPortrait);
					newuic.name = Management.CustomCharacterManager.newCharacters[sea].id;
					newuic.transform.position = ingameslotc.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters/SpongeBob").position;
					newuic.transform.localPosition = ingameslotc.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters/SpongeBob").localPosition;
					newuic.transform.localScale = new Vector3(1, 1, 1);
					newuic.transform.SetParent(ingameslotc.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters"));

					GameObject newuid = GameObject.Instantiate(ingameslotd.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters/SpongeBob").gameObject);
					newuid.GetComponent<RenderImage>().CharacterMetaData = Management.CustomCharacterManager.newCharacters[sea];
					newuid.name = Management.CustomCharacterManager.newCharacters[sea].id;
					newuid.transform.position = ingameslotd.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters/SpongeBob").position;
					newuid.transform.localPosition = ingameslotd.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters/SpongeBob").localPosition;
					newuid.transform.SetParent(ingameslotd.transform.Find("CharacterMask/CharacterRenderVisualizer/Characters"));
					newuid.transform.localScale = new Vector3(1, 1, 1);



				}
				else
				{
					CharLoaderPlugin.LogError("the CharacterSlot object/newCharacters list doesn't exist yet!");
				}

			}
			
		}
	}
}