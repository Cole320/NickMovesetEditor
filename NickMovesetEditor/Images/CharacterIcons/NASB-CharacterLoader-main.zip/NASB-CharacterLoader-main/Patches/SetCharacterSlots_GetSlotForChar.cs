// compile with: /reference:UnityEngine.dll /reference:TypeBindConflicts=UnityEngine.CoreModule.dll  
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using HarmonyLib;
using Nick;
using static Nick.MusicMetaData;
using UnityEngine.Networking;
using System.Linq;
using UnityEngine;
using CharacterLoader.Utils;
using CharacterLoader;
using System.Reflection;

namespace CharacterLoader.Patches
{
	[HarmonyPatch(typeof(SetCharacterSlots), "GetSlotForChar")]
	public class SetCharacterSlots_GetSlotForChar
	{
		public static Dictionary<CharacterMetaData, CharacterSlotData> slotmachine;

		static bool Prefix(SetCharacterSlots __instance, ref CharacterMetaData data, ref CharacterSlotData __result)
		{
			CharacterSlotData result;
			slotmachine = __instance.GetPrivateField<Dictionary<CharacterMetaData, CharacterSlotData>>("slotLookup");
			if (!slotmachine.TryGetValue(data, out result))
			{
				CharLoaderPlugin.LogError("No slot data for " + ((data != null) ? data.ToString() : null));
				
				return true;
			}
			__result = result;
			return true;
		}
	}
}