using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using HarmonyLib;
using Nick;
using UnityEngine;
using UnityEngine.Networking;
using CharacterLoader;
using CharacterLoader.Utils;
using CharacterLoader.Management;
using System.Linq;
using SlapNetwork.Impl.Photon;
using Photon.Pun;

namespace CharacterLoader.Patches
{
    [HarmonyPatch(typeof(SlapNetwork.Impl.Photon.Network), "Connect")]
    class Network_Connect
    {
        static void Postfix(SlapNetwork.Impl.Photon.Network __instance)
        {
            CharLoaderPlugin.LogInfo("trying to apply customChars to photon user " + PhotonNetwork.LocalPlayer.NickName);
            if (Management.CustomCharacterManager.customCharList != null)
            {
                ExitGames.Client.Photon.Hashtable chartable = new ExitGames.Client.Photon.Hashtable();
                chartable.Add("customChars", String.Join("|", Management.CustomCharacterManager.customCharList.ToArray()));

                PhotonNetwork.LocalPlayer.SetCustomProperties(chartable, null, null);
            } else
            {
                CharLoaderPlugin.LogError("You don't have a customCharList!");
            }
            
        }
    }
}