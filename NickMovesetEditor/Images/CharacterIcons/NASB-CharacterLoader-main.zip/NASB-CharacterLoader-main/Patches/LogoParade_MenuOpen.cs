// compile with: /reference:UnityEngine.dll /reference:TypeBindConflicts=UnityEngine.CoreModule.dll  
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using HarmonyLib;
using Nick;
using static Nick.MusicMetaData;
using UnityEngine.Networking;
using System.Linq;
using UnityEngine;
using CharacterLoader.Utils;
using CharacterLoader;
using System.Reflection;

namespace CharacterLoader.Patches
{
	[HarmonyPatch(typeof(LogoParade), "MenuOpen")]
	public class LogoParade_MenuOpen
	{
        static void Prefix()
		{

			CharacterLoader.Management.CustomCharacterManager.Init();
			
		}
	}
}