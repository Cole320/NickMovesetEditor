// compile with: /reference:UnityEngine.dll /reference:TypeBindConflicts=UnityEngine.CoreModule.dll  
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using HarmonyLib;
using Nick;
using UnityEngine.Networking;
using System.Linq;
using UnityEngine;
using CharacterLoader.Utils;
using CharacterLoader;
using System.Reflection;

namespace CharacterLoader.Patches
{
	[HarmonyPatch(typeof(Localization), "GetText", new Type[] { typeof(string) })]
	class Localization_GetText
	{

		public static bool Prefix(Nick.Localization __instance, ref string __result, string id)
		{
			if (Management.CustomCharacterManager.customLocalization.ContainsKey(id))
			{
				CharLoaderPlugin.LogInfo("using custom localization key for " + id);
				__result = Management.CustomCharacterManager.customLocalization[id];
				return false;
			}
			else
			{
				//CharLoaderPlugin.LogInfo("not using custom localization key for " + id);
				return true;
			}
		}
	}
}