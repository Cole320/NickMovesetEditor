// compile with: /reference:UnityEngine.dll /reference:TypeBindConflicts=UnityEngine.CoreModule.dll  
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using HarmonyLib;
using Nick;
using static Nick.MusicMetaData;
using UnityEngine.Networking;
using System.Linq;
using UnityEngine;
using CharacterLoader.Utils;
using CharacterLoader;

namespace CharacterLoader.Patches
{
	[HarmonyPatch(typeof(SetUpGame), "GetValidCharacters")]
	class SetUpGame_GetValidCharacters
	{

		static bool Prefix(SetUpGame __instance, ref List<CharacterMetaData> __result)
		{
			if (Management.CustomCharacterManager.chopsui.Count > GameObject.Find("test").GetComponent<Nick.GameStartScript>().menusys.CharactersDataPreload.CharactersUIMetaData.CharacterUIElementsList.Count)
            {
				GameObject.Find("test").GetComponent<Nick.GameStartScript>().menusys.CharactersDataPreload.CharactersUIMetaData.CharacterUIElementsList = Management.CustomCharacterManager.chopsui;
				CharLoaderPlugin.LogDebug("replacing the CharacterUIMetaData list with the ones with custom characters");

			} else
            {
				CharLoaderPlugin.LogError("CustomCharacterManager's CharacterUIMetaData list is shorter than the game's/doesn't exist!");

			}
			GameVOEventsTrigger_OnTitleScreen.Postfix();
			List<CharacterMetaData> list = new List<CharacterMetaData>(GameObject.Find("test").GetComponent<Nick.GameStartScript>().gmd.characterMetas);
			for (int i = list.Count - 1; i >= 0; i--)
			{
				CharacterMetaData characterMetaData = list[i];
                if (GameObject.Find("test").GetComponent<Nick.GameStartScript>().menusys.CharactersDataPreload.CharactersUIMetaData.CharacterUIElementsList[i] == null)
                {
					CharactersUIMetaData.CharacterUIElements elemental = new CharactersUIMetaData.CharacterUIElements();
					elemental.ID = list[i].id;
					CharLoaderPlugin.LogInfo("the ui element for " + list[i].id + " was null! creating...");
					string PrettifyAssetName(string thename, bool shouldpng)
					{
						string finalstring = thename;
						if (!finalstring.EndsWith(".png") && shouldpng)
						{
							finalstring = finalstring + ".png";
						}
						if (!finalstring.StartsWith("Assets/Resources/"))
						{
							finalstring = "Assets/Resources/" + finalstring;
						}
						CharLoaderPlugin.LogInfo("final name is pretty as " + finalstring);
						return finalstring;
					}

					//elemental.CharacterSlotBackground = cmdasset.LoadAsset<Sprite>(PrettifyAssetName(list[i].resCharacterSlotBackground, true));
					//elemental.CharacterLarge = cmdasset.LoadAssetWithSubAssets<Sprite>(PrettifyAssetName(list[i].skins[0].resPortraits[0], true))[0];
					//elemental.CharacterMedium = cmdasset.LoadAssetWithSubAssets<Sprite>(PrettifyAssetName(list[i].skins[0].resMediumPortraits[0], true))[0];
					//elemental.CharacterSlotBackground = cmdasset.LoadAsset<Sprite>(PrettifyAssetName(list[i].resCharacterSlotBackground, true));
					//elemental.CharacterSmall = cmdasset.LoadAssetWithSubAssets<Sprite>(PrettifyAssetName(list[i].resCSSMiniPortrait, true))[0];
					//elemental.PlayerSlotBackground = cmdasset.LoadAsset<Sprite>(PrettifyAssetName(list[i].resPlayerSlotBackground, true));
					//elemental.VSBackground = cmdasset.LoadAsset<Sprite>(PrettifyAssetName(list[i].resVSBackground, true));
					GameObject.Find("test").GetComponent<Nick.GameStartScript>().menusys.CharactersDataPreload.CharactersUIMetaData.CharacterUIElementsList.Add(elemental);
					GameObject.Find("CharactersDataPreload").GetComponent<CharactersDataPreload>().CharactersUIMetaData.CharacterUIElementsList.Add(elemental);

				}

				if (characterMetaData.id == "char_cb")
				{
					list.RemoveAt(i);
					CharLoaderPlugin.LogError("Character is base; Skipping");
				}
				else if (characterMetaData.isDLC)
				{
					list.RemoveAt(i);
					CharLoaderPlugin.LogError("Character is DLC; Skipping");
				}
				//else if (characterMetaData.hide == true && GameObject.Find("PhotonMono").GetComponent<Photon.Pun.PhotonHandler>().Client.CurrentLobby != null)
                //{
				//	list.RemoveAt(i);
				//	CharLoaderPlugin.LogError("Character is offline only; Skipping");
				//}
			}
			if (GameObject.Find("CharacterSlot") != null && Management.CustomCharacterManager.newCharacters != null)
            {
				List<RenderImage> charlist = CharacterLoader.Utils.GetFielder.GetPrivateField<List<RenderImage>>(GameObject.Find("CharacterSlot/Mask/CharacterSlotRenderVisualizer/RenderVisualizer").GetComponent<RenderVisualizer>(), "charactersList");
				for (int eye = 0; eye < Management.CustomCharacterManager.newCharacters.Length; eye++)
                {
					
					RenderImage renderman = new RenderImage();
					renderman.CharacterMetaData = Management.CustomCharacterManager.newCharacters[eye];
					renderman.name = Management.CustomCharacterManager.newCharacters[eye].id;
					if (!charlist.Contains(renderman))
                    {
						charlist.Add(renderman);
						CharacterLoader.Utils.GetFielder.SetPrivateField(GameObject.Find("CharacterSlot/Mask/CharacterSlotRenderVisualizer/RenderVisualizer").GetComponent<RenderVisualizer>(), "charactersList", charlist);
					}


				}
			}
			__result = list;

			return true; //skip it
		}
	}
}