using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BepInEx;
using Nick;
using CharacterLoader.Utils;
using System.Threading;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace CharacterLoader.Management
{
	public class CustomCharacterManager
	{
		public static string rootCustomAssetsPath;
		public static Hashtable moddedProperties;
		public static List<string> customCharList;
		public static Dictionary<string, string> customLocalization;
		public static AssetBundle debugasset;
		public static CharacterMetaData[] newCharacters;
		public static List<CharactersUIMetaData.CharacterUIElements> chopsui;

		public static void Init()
		{
			rootCustomAssetsPath = Path.Combine(Paths.BepInExRootPath, "CustomChars");
			// Create the folder if it doesn't exist
			Directory.CreateDirectory(rootCustomAssetsPath);

			LoadFromSubDirectories(rootCustomAssetsPath);
		}

		public static void LoadFromSubDirectories(string parentFolderName)
		{
			if (!Directory.Exists(Path.Combine(rootCustomAssetsPath))) return;

				LoadCharsFromFolder(rootCustomAssetsPath);
		}

		public static void LoadCharsFromFolder(string parentFolderName)
		{
			CharLoaderPlugin.LogDebug("called LoadedCharsFromFolder on folder "+parentFolderName);
			CharacterMetaData GetCharacterById(string id)
			{
				foreach (CharacterMetaData characterMetaData in GameObject.Find("test").GetComponent<Nick.GameStartScript>().gmd.characterMetas )
				{
					if (characterMetaData.id == id)
					{
						return characterMetaData;
					}
				}
				CharLoaderPlugin.LogInfo("Character not found: " + id);
				return null;
			}

			string PrettifyAssetName(string thename, bool shouldpng)
            {
				string finalstring = thename;
				if (!finalstring.EndsWith(".png") && shouldpng)
				{
					finalstring = finalstring + ".png";
				}
				if (!finalstring.StartsWith("Assets/Resources/"))
                {
					finalstring = "Assets/Resources/" + finalstring;
                }
				CharLoaderPlugin.LogInfo("final name is pretty as " + finalstring);
				return finalstring;
            }

			CharLoaderPlugin.LogInfo($"LoadCharsFromFolder \"{parentFolderName}\"");
			string path = parentFolderName.Replace("\\", "/");
			foreach (string text in from x in Directory.GetFiles(parentFolderName)
									where (x.ToLower().EndsWith(".assets") && Path.GetFileNameWithoutExtension(x).ToLower().StartsWith("char") && !x.ToLower().EndsWith("_cmd.assets"))
									select x)
			{

				CharLoaderPlugin.LogInfo("Found AssetBundle " + text);
				string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(text);
				UnityEngine.AssetBundle shadersasset = AssetBundle.LoadFromFile(parentFolderName + "/" + fileNameWithoutExtension + ".assets");
				string[] scenePaths = shadersasset.GetAllScenePaths();
				CharLoaderPlugin.LogInfo("Found " + scenePaths.Length + " Scene Paths");
				for (var eye = 0; eye < scenePaths.Length; eye++)
				{
					CharLoaderPlugin.LogInfo("Found Scene Path " + scenePaths[eye] + "");
					string scenereal = scenePaths[eye].Substring(scenePaths[eye].LastIndexOf("/") + 1);
					if (scenereal.ToLower().EndsWith(".unity")) { scenereal = scenereal.Remove(scenereal.Length - 6, 6); }
					CharLoaderPlugin.LogInfo("Scene Path is now " + scenereal);
					if (scenereal.StartsWith("char_"))
                    {
                        CharLoaderPlugin.LogInfo("Loading Character Scene " + scenereal);
                        string dacurrentConfig = GameObject.Find("Agent Loader").GetComponent<Nick.AgentLoading>().idScenes.scenesConfigFile.text + (scenereal + ":" + scenereal + "\n");
                        TextAsset configFinalized = new TextAsset(dacurrentConfig);
                        GameObject.Find("Agent Loader").GetComponent<Nick.AgentLoading>().idScenes.scenesConfigFile = new TextAsset(dacurrentConfig);
                        GameObject.Find("Agent Loader").GetComponent<Nick.AgentLoading>().idScenes.IdDict.Add(scenereal, scenereal);
                        //GameObject.Find("Agent Loader").GetComponent<Nick.AgentLoading>().idScenes.IdDict.Add("skin_shroom_default", "skin_shroom_default");
                        var loadstates = (Dictionary<string, Nick.AgentLoading.LoadState>)HarmonyLib.AccessTools.Field(typeof(Nick.AgentLoading), "loadStates").GetValue(GameObject.Find("Agent Loader").GetComponent<Nick.AgentLoading>());
                        var loadstatus = new Nick.AgentLoading.LoadState();
                        loadstates.Add(scenereal, loadstatus);


                        if (System.IO.File.Exists((parentFolderName + "/" + fileNameWithoutExtension + "_cmd.assets")))
                        {
                            CharLoaderPlugin.LogInfo("this scene has charactermetadata!");
                            UnityEngine.AssetBundle cmdasset = AssetBundle.LoadFromFile(parentFolderName + "/" + fileNameWithoutExtension + "_cmd.assets");
							debugasset = cmdasset; //a double check
							CharLoaderPlugin.LogInfo("i hope i loaded the asset by the name of " + cmdasset.name);
                            CharacterMetaData thecmd = cmdasset.LoadAsset<Nick.CharacterMetaData>("cmd_" + scenereal);
							CharLoaderPlugin.LogInfo("trying to load asset " + "cmd_" + scenereal);
							CharLoaderPlugin.LogInfo("the charactermetadata id is " + thecmd.id);
							CharacterMetaData[] thecmdarray = new CharacterMetaData[GameObject.Find("test").GetComponent<Nick.GameStartScript>().gmd.characterMetas.Length + 1];
							CharLoaderPlugin.LogInfo("cmd array length:" + thecmdarray.Length);
							CharLoaderPlugin.LogInfo("original array length:" + GameObject.Find("test").GetComponent<Nick.GameStartScript>().gmd.characterMetas.Length);
							for (var ariba = 0; ariba < (GameObject.Find("test").GetComponent<Nick.GameStartScript>().gmd.characterMetas.Length); ariba++)
							{
								CharLoaderPlugin.LogInfo("duplicating character: " + GameObject.Find("test").GetComponent<Nick.GameStartScript>().gmd.characterMetas[ariba].id);
								thecmdarray[ariba] = GameObject.Find("test").GetComponent<Nick.GameStartScript>().gmd.characterMetas[ariba];
							}
							CharLoaderPlugin.LogInfo("the second to last character in the array is " + thecmdarray[thecmdarray.Length-2]);
							thecmdarray[thecmdarray.Length - 1] = thecmd;
							CharLoaderPlugin.LogInfo("we should hopefully have loaded " + thecmdarray[thecmdarray.Length - 1].id);
							if (newCharacters == null) { newCharacters = new CharacterMetaData[1]; }
							CharacterMetaData[] newerCharacters = new CharacterMetaData[newCharacters.Length]; newCharacters.CopyTo(newerCharacters, 0);
							newerCharacters[newerCharacters.Length - 1] = thecmdarray[thecmdarray.Length - 1];
							newCharacters = newerCharacters;
							GameObject.Find("test").GetComponent<Nick.GameStartScript>().gmd.characterMetas = new CharacterMetaData[thecmdarray.Length];
							for (var bruh = 0; bruh < (GameObject.Find("test").GetComponent<Nick.GameStartScript>().gmd.characterMetas.Length); bruh++ )
                            {
								CharLoaderPlugin.LogInfo("re-inserting character: " + thecmdarray[bruh].id);
								GameObject.Find("test").GetComponent<Nick.GameStartScript>().gmd.characterMetas[bruh] = thecmdarray[bruh];
                            }
							//CharLoaderPlugin.LogInfo("i swear to god if customCharList was messing it up the whole time ");

							CharactersUIMetaData.CharacterUIElements elemental = new CharactersUIMetaData.CharacterUIElements();
							elemental.ID = thecmdarray[thecmdarray.Length - 1].id;

							

							elemental.CharacterSlotBackground = cmdasset.LoadAsset<Sprite>(PrettifyAssetName(thecmdarray[thecmdarray.Length - 1].resCharacterSlotBackground, true));
							elemental.CharacterLarge = cmdasset.LoadAssetWithSubAssets<Sprite>(PrettifyAssetName(thecmdarray[thecmdarray.Length - 1].skins[0].resPortraits[0], true))[0];
							elemental.CharacterMedium = cmdasset.LoadAssetWithSubAssets<Sprite>(PrettifyAssetName(thecmdarray[thecmdarray.Length - 1].skins[0].resMediumPortraits[0], true))[0];
							elemental.CharacterSlotBackground = cmdasset.LoadAsset<Sprite>(PrettifyAssetName(thecmdarray[thecmdarray.Length - 1].resCharacterSlotBackground, true));
							elemental.CharacterSmall = cmdasset.LoadAssetWithSubAssets<Sprite>(PrettifyAssetName(thecmdarray[thecmdarray.Length - 1].resCSSMiniPortrait, true))[0];
							elemental.PlayerSlotBackground = cmdasset.LoadAsset<Sprite>(PrettifyAssetName(thecmdarray[thecmdarray.Length - 1].resPlayerSlotBackground, true));
							elemental.VSBackground = cmdasset.LoadAsset<Sprite>(PrettifyAssetName(thecmdarray[thecmdarray.Length - 1].resVSBackground, true));
							GameObject.Find("test").GetComponent<Nick.GameStartScript>().menusys.CharactersDataPreload.CharactersUIMetaData.CharacterUIElementsList.Add(elemental);
							chopsui = GameObject.Find("test").GetComponent<Nick.GameStartScript>().menusys.CharactersDataPreload.CharactersUIMetaData.CharacterUIElementsList;

							if (GameObject.Find("CharacterSlot") == null) { Resources.Load("menu/menuelements/characterselect/CharacterSlot"); }
							if (GameObject.Find("CharacterSlot") != null && Management.CustomCharacterManager.newCharacters != null)
							{
								GameObject newcharicon = GameObject.Instantiate(GameObject.Find("CharacterSlot/Mask/CharacterSlotRenderVisualizer/RenderVisualizer/Characters/SpongeBob"));
								newcharicon.GetComponent<RenderImage>().CharacterMetaData = Management.CustomCharacterManager.newCharacters[newCharacters.Length-1];
								newcharicon.name = Management.CustomCharacterManager.newCharacters[newCharacters.Length-1].id;
								newcharicon.transform.parent = GameObject.Find("CharacterSlot/Mask/CharacterSlotRenderVisualizer/RenderVisualizer/Characters").transform;


							}
							else
							{
								CharLoaderPlugin.LogError("the CharacterSlot object/newCharacters list doesn't exist yet!");
							}


							if (customCharList == null) { customCharList = new List<string>(); }
							customCharList.Add(scenereal);
							//CharLoaderPlugin.LogInfo("i swear to god if moddedProperties was messing it up the whole time ");
							if (moddedProperties == null) { moddedProperties = new Hashtable(); }
							moddedProperties.Add("moddedChars", customCharList);
							//cmdasset.Unload(false);
							if (customLocalization == null) { customLocalization = new Dictionary<string, string>(); }
							if (System.IO.File.Exists((parentFolderName + "/" + fileNameWithoutExtension + "_loc.txt")))
							{
								string makingalist = System.IO.File.ReadAllText(parentFolderName + "/" + fileNameWithoutExtension + "_loc.txt");
								CharLoaderPlugin.LogInfo("Text of _loc.txt: \n" + makingalist);
								string[] checkingittwice = makingalist.Split('\n');
								CharLoaderPlugin.LogInfo("first line of localization list for the character is " + checkingittwice[0]);
								foreach (string gonnafindout in checkingittwice)
								{
									string[] naughtyornice = gonnafindout.Split('|');
									if (naughtyornice.Length >= 1 && naughtyornice[0] != null)
									{
										Management.CustomCharacterManager.customLocalization.Add(naughtyornice[0], naughtyornice[1]);
									}
									else
									{
										CharLoaderPlugin.LogError("localization key " + naughtyornice + " didn't have enough information!");
									}
								}

							}
							else
							{
								CharLoaderPlugin.LogError("Character has no _loc.txt associated, custom localization might break!");
							}
						}
                        else
                        {
                            CharLoaderPlugin.LogError("Character Scene " + scenereal + " has no CharacterMetaData assetbundle! mark it under " + fileNameWithoutExtension + "_cmd.assets!");
							
						}
                    }
                    else if (scenereal.StartsWith("skin_"))
                    {

						if (GetCharacterById("char_" + scenereal.Split('_')[1]) != null)
                        {
							string dacurrentConfig = GameObject.Find("Agent Loader").GetComponent<Nick.AgentLoading>().idScenes.scenesConfigFile.text + (scenereal + ":" + scenereal + "\n");
							TextAsset configFinalized = new TextAsset(dacurrentConfig);
							GameObject.Find("Agent Loader").GetComponent<Nick.AgentLoading>().idScenes.scenesConfigFile = new TextAsset(dacurrentConfig);
							GameObject.Find("Agent Loader").GetComponent<Nick.AgentLoading>().idScenes.IdDict.Add(scenereal, scenereal);
							var loadstates = (Dictionary<string, Nick.AgentLoading.LoadState>)HarmonyLib.AccessTools.Field(typeof(Nick.AgentLoading), "loadStates").GetValue(GameObject.Find("Agent Loader").GetComponent<Nick.AgentLoading>());
							var loadstatus = new Nick.AgentLoading.LoadState();
							loadstates.Add(scenereal, loadstatus);
							CharacterMetaData charofskin = GetCharacterById("char_" + scenereal.Split('_')[1]);
							CharacterMetaData.CharacterSkinMetaData newskin = new CharacterMetaData.CharacterSkinMetaData();
                            for (var longing = 0; longing < charofskin.skins.Length; longing++)
                            {
								if (charofskin.skins[longing].id == scenereal) {
									newskin.id = charofskin.skins[longing].id;
									newskin.resMediumPortraits = charofskin.skins[longing].resMediumPortraits;
									newskin.resMiniPortraits = charofskin.skins[longing].resMiniPortraits;
									newskin.resPortraits = charofskin.skins[longing].resPortraits;
									newskin.locNames = charofskin.skins[longing].locNames;
								}
							}
							CharacterMetaData.CharacterSkinMetaData[] newskinsarray = new CharacterMetaData.CharacterSkinMetaData[charofskin.skins.Length];
							newskinsarray[charofskin.skins.Length-1] = newskin;
							charofskin.skins = newskinsarray;
							//if ()
							// {
							//
							//   }

						}
						else
                        {
							CharLoaderPlugin.LogError(scenereal + " has no character to go to!");

						}

                    }

				}

			}

		}
	}
}