﻿using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using System.Reflection;
using UnityEngine;

namespace CharacterLoader
{
    [BepInPlugin("craftersshaft.nasbmods.charloader", "NASB Character Loader", "0.0.1")]
    public class CharLoaderPlugin : BaseUnityPlugin
    
    {
        internal static CharLoaderPlugin Instance;
        public static string[] resourceNames;
        private void Awake()
        {
            // Plugin startup logic
            Logger.LogInfo($"Plugin {PluginInfo.PLUGIN_GUID} is loaded!");
            Instance = this;
            Harmony.CreateAndPatchAll(Assembly.GetExecutingAssembly());
            resourceNames = Assembly.GetExecutingAssembly().GetManifestResourceNames();
        }

    internal static void LogDebug(string message) => Instance.Log(message, LogLevel.Debug);
        internal static void LogInfo(string message) => Instance.Log(message, LogLevel.Info);
        internal static void LogError(string message) => Instance.Log(message, LogLevel.Error);
        private void Log(string message, LogLevel logLevel) => Logger.Log(logLevel, message);

 
        }
    }
